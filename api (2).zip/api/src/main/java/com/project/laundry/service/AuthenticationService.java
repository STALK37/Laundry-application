package com.project.laundry.service;

import com.project.laundry.config.JwtService;
import com.project.laundry.entity.user.Role;
import com.project.laundry.entity.user.User;
import com.project.laundry.exception.UserExistsException;
import com.project.laundry.repo.UserRepository;
import com.project.laundry.service.model.AuthenticationRequest;
import com.project.laundry.service.model.AuthenticationResponse;
import com.project.laundry.service.model.RegisterAdminRequest;
import com.project.laundry.service.model.RegisterCustomerRequest;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthenticationService {

  private final UserRepository repository;
  private final PasswordEncoder passwordEncoder;
  private final JwtService jwtService;
  private final AuthenticationManager authenticationManager;

  @SneakyThrows
  public AuthenticationResponse register(RegisterCustomerRequest request) {
    Optional<User> userByEmailOpt = repository.findByEmail(request.getEmail());
    if (userByEmailOpt.isPresent()) {
      throw new UserExistsException();
    }

    User user = User.builder()
        .firstname(request.getFirstname())
        .lastname(request.getLastname())
        .email(request.getEmail())
        .password(passwordEncoder.encode(request.getPassword()))
        .gender(request.getGender())
        .role(Role.USER)
        .build();

    repository.save(user);
    String jwtToken = jwtService.generateToken(user);
    return AuthenticationResponse.builder()
        .token(jwtToken)
        .build();
  }

  public AuthenticationResponse login(AuthenticationRequest request) {
    authenticationManager.authenticate(
        new UsernamePasswordAuthenticationToken(
            request.getEmail(),
            request.getPassword()
        )
    );
    UserDetails userDetails = repository.findByEmail(request.getEmail())
        .orElseThrow();
    String jwtToken = jwtService.generateToken(userDetails);
    return AuthenticationResponse.builder()
        .token(jwtToken)
        .build();
  }

  @SneakyThrows
  public AuthenticationResponse registerAdmin(RegisterAdminRequest registerAdminRequest) {
    Optional<User> userByEmailOpt = repository.findByEmail(registerAdminRequest.getEmail());
    if (userByEmailOpt.isPresent()) {
      throw new UserExistsException();
    }
    final User admin = User.builder()
        .userName(registerAdminRequest.getUsername())
        .companyName(registerAdminRequest.getCompanyName())
        .address(registerAdminRequest.getAddress())
        .email(registerAdminRequest.getEmail())
        .password(passwordEncoder.encode(registerAdminRequest.getPassword()))
        .role(Role.ADMIN)
        .build();
    repository.save(admin);
    String jwtToken = jwtService.generateToken(admin);
    return AuthenticationResponse.builder()
        .token(jwtToken)
        .build();
  }
}
