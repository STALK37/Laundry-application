package com.project.laundry.controller.model;

import com.project.laundry.entity.user.Role;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDto {

  private String username;
  private String email;
  private String firstname;
  private String lastname;
  private String companyName;
  private String address;
  private Role role;

  public UserDto(String username, String email, String firstname, String lastname,
      String companyName, String address, Role role) {
    this.username = username;
    this.email = email;
    this.firstname = firstname;
    this.lastname = lastname;
    this.companyName = companyName;
    this.address = address;
    this.role = role;
  }

}
