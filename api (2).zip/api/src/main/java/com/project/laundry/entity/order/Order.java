package com.project.laundry.entity.order;

import static jakarta.persistence.GenerationType.IDENTITY;

import com.project.laundry.entity.order.orderModel.Tariff;
import com.project.laundry.entity.user.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity(name = "Order")
@Table(name = "orders")
@Getter
@Setter
public class Order {

  public Order() {
  }

  @Id
  @GeneratedValue(strategy = IDENTITY)
  @Column(name = "id", unique = true, nullable = false, insertable = false, updatable = false)
  private Long id;


  @Enumerated(EnumType.STRING)
  private Tariff tariff;

  @CreationTimestamp
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "created_at", updatable = false)
  private Date createdAt;

  @UpdateTimestamp
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "updated_at")
  private Date updatedAt;

  @ManyToOne
  @JoinColumn(
      name = "customer_id", referencedColumnName = "id",
      updatable = false
  )
  private User customer;

  @ManyToOne
  @JoinColumn(
      name = "admin_id", referencedColumnName = "id"
  )
  private User admin;

  private String address;
  private Date selectedDate;


}
