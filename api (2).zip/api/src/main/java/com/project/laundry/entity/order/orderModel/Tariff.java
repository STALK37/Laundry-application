package com.project.laundry.entity.order.orderModel;

import lombok.Getter;

@Getter
public enum Tariff {
  EXPENSIVE,
  MEDIUM,
  CHEAP,
}
