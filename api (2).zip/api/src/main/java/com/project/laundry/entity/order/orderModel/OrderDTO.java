package com.project.laundry.entity.order.orderModel;

import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OrderDTO {
    private String address;
    private Date selectedDate;
    private Tariff tariff;
}
