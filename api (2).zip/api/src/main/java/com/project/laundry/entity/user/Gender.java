package com.project.laundry.entity.user;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;

public enum Gender {
    @JsonEnumDefaultValue

    MALE,
    FEMALE,
    OTHER

}
