package com.project.laundry.controller;


import com.project.laundry.controller.model.UserDto;
import com.project.laundry.entity.order.Order;
import com.project.laundry.entity.order.orderModel.OrderDTO;
import com.project.laundry.entity.user.Role;
import com.project.laundry.entity.user.User;
import com.project.laundry.repo.OrderRepository;
import com.project.laundry.service.AuthenticationService;
import com.project.laundry.service.model.AuthenticationRequest;
import com.project.laundry.service.model.AuthenticationResponse;
import com.project.laundry.service.model.RegisterAdminRequest;
import com.project.laundry.service.model.RegisterCustomerRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3001")
@RequestMapping("/users")
@RequiredArgsConstructor
public class BaseController {

  private final AuthenticationService service;
  private final OrderRepository orderRepository;

  @PostMapping("/customers/register")
  public ResponseEntity<AuthenticationResponse> register(
      @RequestBody RegisterCustomerRequest request
  ) {
    return ResponseEntity.ok(service.register(request));
  }


  @PostMapping("/admins/register")
  public ResponseEntity<AuthenticationResponse> adminRegister(
      @RequestBody RegisterAdminRequest request
  ) {
    return ResponseEntity.ok(service.registerAdmin(request));
  }

  @PostMapping("/login")
  public ResponseEntity<AuthenticationResponse> login(
      @RequestBody AuthenticationRequest request
  ) {
    return ResponseEntity.ok(service.login(request));
  }

  @GetMapping("/info")
  public ResponseEntity<UserDto> getUserInfo(@AuthenticationPrincipal User user) {
    return ResponseEntity.ok(
        new UserDto(user.getRealUsername(), user.getEmail(), user.getFirstname(), user.getLastname(),
            user.getCompanyName(), user.getAddress(), user.getRole()));
  }

  @PostMapping("/orders/create")
  public Order createOrder(@RequestBody OrderDTO orderRequest, @AuthenticationPrincipal User user) {
    Order order = new Order();

    order.setAddress(orderRequest.getAddress());
    order.setSelectedDate(orderRequest.getSelectedDate());
    order.setTariff(orderRequest.getTariff());
    order.setCustomer(user);

    return orderRepository.save(order);
  }

  @GetMapping("/orders/admins")
  public List<Order> getAdminOrders(@AuthenticationPrincipal User user) {
    if (user == null) {
      // Ideally, you would throw a custom exception here
      // which Spring can then handle to return a 404 status code
      throw new RuntimeException("Admin not found");
    }

    return orderRepository.findByAdmin(user);
  }


  @PostMapping("/orders/{orderId}/accept")
  public Order acceptOrder(@PathVariable Long orderId, @AuthenticationPrincipal User user) {
    if (user == null || !user.getRole().equals(Role.ADMIN)) {
      throw new RuntimeException("Permission denied");
    }
    Order order = orderRepository.findById(orderId).orElseThrow();
    order.setAdmin(user);
    return orderRepository.saveAndFlush(order);
  }

  @GetMapping("/orders/customers")
  public List<Order> getCustomerOrders(@AuthenticationPrincipal User user) {
    if (user == null) {
      // Ideally, you would throw a custom exception here
      // which Spring can then handle to return a 404 status code
      throw new RuntimeException("Customer not found");
    }

    return orderRepository.findByCustomer(user);
  }

}
