package com.project.laundry.entity.user;

public enum Role {

    USER,
    ADMIN
}
