package com.project.laundry.service.model;

import com.project.laundry.entity.user.Gender;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import lombok.NonNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegisterCustomerRequest {

    private String firstname;
    private String lastname;
    @NonNull private String email;
    @NonNull private String password;
    private Gender gender;

}
