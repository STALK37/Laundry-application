package com.project.laundry.repo;

import com.project.laundry.entity.order.Order;
import com.project.laundry.entity.user.User;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface OrderRepository extends JpaRepository<Order, Long> {

  List<Order> findByCustomer(User user);

  @Query("select o from Order o WHERE o.admin=:admin or o.admin is null")
  List<Order> findByAdmin(User admin);
}
