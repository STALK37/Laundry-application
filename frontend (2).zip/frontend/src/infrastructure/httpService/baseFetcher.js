import axios from "axios";

class BaseFetcher {

    constructor(domain) {
        this.domain = domain;
    }

    async request({
                      url,
                      method,
                      signal,
                      headerOptions = {},
                      data = {},
                  }) {
        const token = localStorage.getItem("token");

        console.log(url, 'url', method.toLowerCase(), token)

        const response = method.toLowerCase() === "get" ? await axios[method.toLowerCase()](`http://localhost:8080/${url}`, {
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
                ...headerOptions,
            },
        }) : await axios[method.toLowerCase()](`http://localhost:8080/${url}`, JSON.stringify(data), {
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
                ...headerOptions,
            },
        });

        if (response.status !== 200) {
            const errorRes = await response.json();
            const message = errorRes?.message;

            throw {
                message,
                statusCode: response.status,
            };
        }

        return response.data;
    }
}

export default BaseFetcher;
