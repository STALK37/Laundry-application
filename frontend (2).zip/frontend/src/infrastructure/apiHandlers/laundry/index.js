import BaseApiHandler from "../baseApiHandler";

class LaundryApiHandler extends BaseApiHandler {
  constructor() {
    super();
  }

  async getUser() {
    const t = await this.request.laundryFetcher.get({
      url: "users/info",
    });

    console.log(t, "Asdasd")
    return t;
  }

  async getOrders(isAdmin) {
    return await this.request.laundryFetcher.get({
      url: isAdmin ? "users/orders/admins" : "users/orders/customers",
    });
  }

  async acceptOrder(orderId) {
    return await this.request.laundryFetcher.post({
      url: `users/orders/${orderId}/accept`,
    });
  }

  async createOrder(order) {
    return await this.request.laundryFetcher.post({
      url: `users/orders/create`,
      data: order,
    });
  }
}

const laundryApiHandler = new LaundryApiHandler();

export default laundryApiHandler;
