import React, { useState, Fragment } from "react";
import { useNavigate } from "react-router-dom";
import "./customerPart.css";
import { useMutation, useQuery } from "@tanstack/react-query";
import { laundryApiHandler } from "../../../infrastructure/apiHandlers";
import LocationForm, { TARIFF_VALUES } from "./components/LocationForm"; // Update this path as needed

function CustomerPart() {
    const { data: userData } = useQuery({
        queryKey: ["user"],
        queryFn: () => laundryApiHandler.getUser(),
    })
    console.log(userData);
    const {mutate: createOrder} = useMutation({
        mutationFn: (order) => laundryApiHandler.createOrder(order),
        onSuccess: () => {
            navigate('/customer');
        }
    })

    const navigate = useNavigate();

    const [formValues, setFormValues] = useState({ address: "", tariff: TARIFF_VALUES.Cheap, selectedDate: "" })

    const handleLogout = () => {
        // Example logout implementation
        localStorage.removeItem("token"); // Assuming token is stored in localStorage
        navigate("/"); // Redirect to home/login page
    };

    const onSubmit = async () => {
        await createOrder(formValues)
    }

    return (
        <Fragment>
            <header className="navbar">
                <div
                    className="profile"
                    onClick={() => document.getElementById("profileImageInput").click()}
                >
                    <div className="profile-text">{userData.firstname} {userData.lastname}</div>
                </div>
                <button onClick={handleLogout} className="logout-button">
                    Log Out
                </button>
            </header>
            <div className="location-info" onClick={() => navigate('/customer')}>{"< Back to my orders"}</div>
            <div className="location-wrapper">
                <div>
                    <LocationForm formValues={formValues} setFormValues={setFormValues}/>
                </div>
            </div>
            <div className="buttons">
                <button className="new-order-button" onClick={onSubmit}>Submit</button>
            </div>
        </Fragment>
    );
}

export default CustomerPart;
