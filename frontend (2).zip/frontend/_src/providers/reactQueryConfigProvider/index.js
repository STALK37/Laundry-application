import { ReactQueryClientConfigInstance } from '../../configs/reactQuery';
import {QueryClientProvider} from "@tanstack/react-query";
import { useState } from "react";

const ReactQueryConfigProvider = ({ children }) => {
    const [queryClient] = useState(ReactQueryClientConfigInstance)

    return (
        <QueryClientProvider client={queryClient}>
            {children}
        </QueryClientProvider>
    )
}

export default ReactQueryConfigProvider;
