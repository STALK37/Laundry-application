import {QueryClient, QueryCache, MutationCache} from "@tanstack/react-query"

const ReactQueryClientConfigInstance = () => new QueryClient({
    queryCache: new QueryCache({}),
    mutationCache: new MutationCache({}),
    defaultOptions: {
        queries: {
            refetchOnWindowFocus: false,
            retry: false,
        },
    },
});

export default ReactQueryClientConfigInstance;
