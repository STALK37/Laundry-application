const {LAUNDRY_BACKEND_URL} = process.env;

export const EnvConfig = {
    LAUNDRY_BACKEND_URL,
}
