import axios from "axios";

class BaseFetcher {

  constructor(domain) {
    this.domain = domain;
  }

  async request({
    url,
    method,
    signal,
    headerOptions = {},
    data = { },
  }) {
    const token = localStorage.getItem("token");
console.log({
  headers: {
    Authorization: `Bearer ${token}`,
    ...headerOptions,
  },
  signal,
});
    const response = method.toLowerCase() === "get" ? await axios[method.toLowerCase()](`http://localhost:8080/${url}`, {
      headers: {
        Authorization: `Bearer ${token}`,
        ...headerOptions,
      },
      signal,
    }) : await axios[method.toLowerCase()](`http://localhost:8080/${url}`, JSON.stringify(data), {
      headers: {
        Authorization: `Bearer ${token}`,
        ...headerOptions,
      },
      signal,
    });

    if (response.status !== 200) {
      const errorRes = await response.json();
      const message = errorRes?.message;

      throw {
        message,
        statusCode: response.status,
      };
    }

    return response.data;
  }
}

export default BaseFetcher;
