import BaseFetcher from "./baseFetcher";

class HttpService extends BaseFetcher {
  constructor(domain) {
    super(domain);
  }

  get({ url, headerOptions = {} }) {
    return this.request({
      method: "GET",
      url,
      headerOptions: {
        ...headerOptions,
      },
    });
  }

  post({ url, headerOptions = {}, data = {} }) {
    return this.request({
      method: "POST",
      url,
      headerOptions: {
        ...headerOptions,
      },
      data,
    });
  }
}

export default HttpService;
