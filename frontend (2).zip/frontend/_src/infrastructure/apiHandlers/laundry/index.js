import BaseApiHandler from "../baseApiHandler";

class LaundryApiHandler extends BaseApiHandler {
  constructor() {
    super();
  }

  async getUser() {
    const t = await this.request.laundryFetcher.get({
      url: "users/info",
    });

    console.log(t, "Asdasd")
    return t;
  }

  async getOrders(isAdmin) {
    return await this.request.laundryFetcher.get({
      url: isAdmin ? "api/orders/admins" : "api/orders/customers",
    });
  }

  async acceptOrder(orderId) {
    return await this.request.laundryFetcher.post({
      url: `api/orders/${orderId}/accept`,
    });
  }

  async createOrder(order) {
    return await this.request.laundryFetcher.post({
      url: `api/orders/create`,
      data: order,
    });
  }
}

const laundryApiHandler = new LaundryApiHandler();

export default laundryApiHandler;
