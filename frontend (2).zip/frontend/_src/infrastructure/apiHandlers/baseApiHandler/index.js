import { HttpService } from "../../httpService";
import { EnvConfig } from "../../../configs/env";

class BaseApiHandler {
  constructor() {
    this.request = {
      laundryFetcher: new HttpService(EnvConfig.LAUNDRY_BACKEND_URL),
    };
  }
}

export default BaseApiHandler;
