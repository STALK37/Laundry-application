import React, { useLayoutEffect, useState } from 'react';
import { useNavigate, Link, useSearchParams } from 'react-router-dom';
import '../../../App.css'; // Adjust the path as necessary
import axios from 'axios';
import { laundryApiHandler } from "../../../infrastructure/apiHandlers";
import { useQueryClient } from "@tanstack/react-query";

function SignInPage() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const roleQueryParam = searchParams.get("role");
    const createAccountBasedRoleLink = roleQueryParam === "user" ? "/customer/registration" : "/admin/registration"
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    useLayoutEffect(() => {
        const token = localStorage.getItem('token');
        if (token) {
            navigate('/'); // Redirect to admin profile if a token exists
        }
    }, [navigate]);
    console.log(createAccountBasedRoleLink, "roleQueryParam");

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(''); // Reset error message

        try {
            const config = { headers: {} };
            const body = JSON.stringify({ email, password });
            const endpoint = 'http://localhost:8080/users/login';

            const response = await axios.post(endpoint, body, config);
            // Assuming both endpoints return a token
            if (response.data && response.data.token) {
                localStorage.setItem('token', response.data.token); // Store the token
                const userData = await laundryApiHandler.getUser();
                // Redirect based on the role
                if (userData.role === 'ADMIN') {
                    console.log('/admin')
                    navigate('/admin');
                } else {
                    console.log('/customer')
                    navigate('/customer'); // Ensure you have a route for the customer part
                }
            } else {
                setError('Failed to sign in. Please check your credentials and try again.');
            }
        } catch (err) {
            setError('Failed to sign in. Please check your credentials and try again.');
        }
    };

    return (
        <div className="header">
            <div className="Total">
                <form onSubmit={handleLogin}>
                    <div className="textSign">
                        <h1 className="textSign1">Sign in!</h1>
                    </div>
                    {error && <div className="error-message">{error}</div>}
                    <div className="InputPart">
                        <input type="email" id="email" name="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} required />
                        <input type="password" id="password" name="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} required />
                    </div>
                    <div className="LoginInButton">
                        <button type="submit">Log in</button>
                    </div>
                </form>
                <div className="CreateAccountButton">
                    <Link to={createAccountBasedRoleLink} className="account-link">Create New Account</Link>
                </div>
            </div>
        </div>
    );
}

export default SignInPage;
