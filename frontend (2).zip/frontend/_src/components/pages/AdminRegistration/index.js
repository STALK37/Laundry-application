import React, { useState, useEffect, Fragment } from 'react';
import { useNavigate } from 'react-router-dom';
import './adminRegistration.css'; // Make sure the path is correct
import axios from 'axios';

function AdminRegistration() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
        repeatPassword: '',
        companyName: '',
        address: ''
    });
    const [error, setError] = useState('');

    const { username, email, password, repeatPassword, companyName, address } = formData;

    const onChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });

    const onSubmit = async e => {
        e.preventDefault();
        setError('');

        if (password !== repeatPassword) {
            setError('Passwords do not match.');
            return;
        }

        try {
            const config = {
                headers: {},
            };

            const body = JSON.stringify({
                username,
                email,
                password,
                companyName,
                address
            });

            const response = await axios.post('http://localhost:8080/users/admins/register', body, config);
            localStorage.setItem('token', response.data.token); // Store the token in localStorage
            navigate('/admin'); // Redirect to admin profile page upon successful registration
        } catch (err) {
            console.log(err);
            const errorMessage = err.response && err.response.data && err.response.data.message
                ? err.response.data.message
                : 'An error occurred during registration';
            setError(errorMessage);
        }
    };

    return (
        <Fragment>
            <section className="container">
                <header className="adminHeader">
                    <h1>Admin Registration</h1>
                </header>
                {error && <div className="alert alert-danger">{error}</div>}
                <form className="registrationForm" onSubmit={onSubmit}>
                    <div className="form-group">
                        <input type="text" placeholder="Username" name="username" value={username} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="email" placeholder="Email" name="email" value={email} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="password" placeholder="Password" name="password" value={password} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="password" placeholder="Repeat Password" name="repeatPassword" value={repeatPassword} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="text" placeholder="Company Name" name="companyName" value={companyName} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="text" placeholder="Address" name="address" value={address} onChange={onChange} required />
                    </div>
                    <div className="submit-group">
                        <button type="submit" className="SubmitButton">Submit</button>
                    </div>
                </form>
            </section>
        </Fragment>
    );
}

export default AdminRegistration;
