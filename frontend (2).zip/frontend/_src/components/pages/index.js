export {default as AdminPartPage} from './AdminPart';
export {default as SignInPage} from './SignInPage';
export {default as RegistrationAsRolePage} from './RegistrationAsRolePage';
export {default as AdminRegistrationPage} from './AdminRegistration';
export {default as CustomerPartPage} from './CustomerPart';
export {default as CustomerRegistrationPage} from './CustomerRegistration';
export {default as MainLayout} from './MainLayout';
export {default as OrdersPage} from './Orders';
