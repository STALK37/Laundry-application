import '../../customerPart.css'

export const TARIFF_VALUES = {
    Expensive: 'EXPENSIVE',
    Medium: 'MEDIUM',
    Cheap: 'CHEAP',
}

const LocationForm = ({ formValues: { address, tariff, selectedDate }, setFormValues }) => {
    const onAddressChange = (e) => {
        setFormValues(prev => ({ ...prev, address: e.target.value }));
    };


    const onTariffChange = (e) => {
        console.log(e, 'tariff')
        setFormValues(prev => ({ ...prev, tariff: e.target.value }));
    }


    const onDateChange = (e) => {
        console.log(e, 'date')

        setFormValues(prev => ({ ...prev, selectedDate: e.target.value }));
    }

    return <form>
        <h4>Please enter service details</h4>
        <div className="form-content">
            <div>
                <label htmlFor="order-address">Address</label>
                <input required placeholder="Enter address here" id="order-address" type="text" value={address}
                       onChange={onAddressChange}/>
            </div>
            <div className="tariff-options">
                <div>
                    <input name="tariff" id={TARIFF_VALUES.Cheap} value={TARIFF_VALUES.Cheap} defaultChecked type="radio"
                           onChange={onTariffChange}/>
                    <label htmlFor={TARIFF_VALUES.Cheap}>
                        1 - 5kg (5€)
                    </label>

                </div>
                <div>
                    <input name="tariff" id={TARIFF_VALUES.Medium} value={TARIFF_VALUES.Medium} type="radio"
                           onChange={onTariffChange}/>
                    <label htmlFor={TARIFF_VALUES.Medium}>5 - 10kg (10€)
                    </label>

                </div>
                <div>
                    <input name="tariff" id={TARIFF_VALUES.Expensive} value={TARIFF_VALUES.Expensive}
                           type="radio"
                           onChange={onTariffChange}/>
                    <label htmlFor={TARIFF_VALUES.Expensive}>10 - 15kg (15€)</label>

                </div>
            </div>
            <div>
                <label htmlFor="order-date">Date</label>
                <input required id="order-date" type="date" value={selectedDate} onChange={onDateChange}/>
            </div>
        </div>
    </form>
}

export default LocationForm;
