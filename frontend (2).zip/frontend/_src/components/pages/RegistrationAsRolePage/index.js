import React, { Fragment } from 'react';
import { Link } from "react-router-dom";
import './user.css';  // Ensure this path is correct

function RegistrationAsRolePage() {
    return (
        <Fragment>
            <div className="All">
                <Link to="/sign-in?role=user" className="User-box Box">User</Link>
                <Link to="/sign-in?role=admin" className="Service-box Box">Service</Link>
                <Link to="/contactUs" className="ContactUs-box Box">Contact Us</Link>
            </div>
        </Fragment>
    );
}

export default RegistrationAsRolePage;
