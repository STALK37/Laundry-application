import React, { useState, Fragment } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from "@tanstack/react-query";
import { laundryApiHandler } from "../../../infrastructure/apiHandlers"; // Make sure this path is correct
import './adminPart.css';

function AdminPart() {
    const { data: userData } = useQuery({
        queryKey: ["user"],
        queryFn: () => laundryApiHandler.getUser(),
    })

    const navigate = useNavigate();
    const [profileImage, setProfileImage] = useState('default-avatar.png');

    // Handler for file input change
    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            setProfileImage(URL.createObjectURL(file));
        }
    };

    // Logout and clear token from localStorage
    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/'); // Adjust this if your login route is different
    };

    return (
        <Fragment>
            <header className="navbar">
                <div className="profile-text">{userData.username}, {userData.companyName}</div>
                {/* Adding Logout Button with the same style as "Orders" button */}
                <button className="orders-button" onClick={handleLogout}>Log Out</button>
            </header>

            <main>
                <div className="location-info">Location</div>

                <section className="map-container">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d12145.698557480386!2d-3.6927540999999997!3d40.4437375!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sru!2ses!4v1707158524144!5m2!1sru!2ses"
                            width="600" height="450" style={{border:0}} allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
                </section>

                <section className="orders-section">
                    <Link to="orders" className="orders-button">Orders</Link>
                </section>
            </main>
        </Fragment>
    );
}

export default AdminPart;
