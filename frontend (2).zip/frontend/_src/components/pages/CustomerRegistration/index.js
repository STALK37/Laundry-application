import React, { useState, useEffect, Fragment } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './customerRegistration.css'; // Adjust the path to your CSS file as needed

function CustomerRegistration() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        firstname: '',
        lastname: '',
        email: '',
        password: '',
        repeatPassword: '',
        gender: '',
    });
    const [error, setError] = useState('');

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (token) {
            navigate('/customerPart'); // Redirect to customer profile page if already logged in
        }
    }, [navigate]);

    const { firstname, lastname, email, password, repeatPassword, gender } = formData;

    const onChange = e => setFormData({ ...formData, [e.target.name]: e.target.value });

    const onSubmit = async e => {
        e.preventDefault();
        if (password !== repeatPassword) {
            setError('Passwords do not match.');
            return;
        }

        try {
            const config = {
                headers: {},
            };

            const body = JSON.stringify({
                firstname,
                lastname,
                email,
                password,
                gender: gender.toUpperCase(),
            });

            const response = await axios.post('http://localhost:8080/users/customers/register', body, config);
            localStorage.setItem('token', response.data.token); // Store token received from backend
            navigate('/customer'); // Navigate to customer profile page
        } catch (err) {
            if (err.response) {
                setError(err.response.data.message || 'Registration failed. Please try again.');
            } else if (err.request) {
                setError('Network error. Please check your connection and try again.');
            } else {
                setError('An error occurred. Please try again.');
            }
        }
    };

    const handleLogout = () => {
        localStorage.removeItem('token'); // Remove the token from localStorage
        navigate('/Home'); // Redirect to Home page after logging out
    };

    return (
        <Fragment>
            <div className="container">
                <div className="CustomerHeader">
                    <h1>Customer Registration</h1>
                </div>
                {error && <div className="alert alert-danger">{error}</div>}
                <form className="registrationForm" onSubmit={onSubmit}>
                    <div className="form-group">
                        <input type="text" placeholder="First Name" name="firstname" value={firstname} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="text" placeholder="Last Name" name="lastname" value={lastname} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="email" placeholder="Email" name="email" value={email} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="password" placeholder="Password" name="password" value={password} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <input type="password" placeholder="Repeat Password" name="repeatPassword" value={repeatPassword} onChange={onChange} required />
                    </div>
                    <div className="form-group">
                        <select name="gender" value={gender} onChange={onChange} required>
                            <option value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div className="submit-group">
                        <button type="submit" className="SubmitButton">Submit</button>
                    </div>
                </form>
            </div>
        </Fragment>
    );
}

export default CustomerRegistration;
