import React, { Fragment } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { laundryApiHandler } from "../../../infrastructure/apiHandlers";
import "./adminOrders.css";
import { useNavigate } from "react-router-dom";
const AdminOrders = () => {
    const navigate = useNavigate();
    const { data: userData } = useQuery({
        queryKey: ["user"],
        queryFn: () => laundryApiHandler.getUser(),
    })
    const isAdmin = userData.role === "ADMIN";

    console.log(userData);

    const { data: adminOrders, isLoading, refetch } = useQuery({
        queryKey: ["adminOrders"],
        queryFn: () => laundryApiHandler.getOrders(isAdmin),
        enabled: !!userData
    })

    const {mutate: acceptOrder} = useMutation({
        mutationFn: (orderId) => laundryApiHandler.acceptOrder(orderId),
        onSuccess: () => {
            refetch()
        }
    })

    const acceptOrderHandler = async (orderId) => {
        const acceptOrderRes = await acceptOrder(orderId);
        console.log(acceptOrderRes, "orderId");

    }

    const handleLogout = () => {
        // Example logout implementation
        localStorage.removeItem('token'); // Assuming token is stored in localStorage
        navigate('/'); // Redirect to home/login page
    };

    const onClickNewOrder = () => {
        navigate('new-order');
    }

    return (
        <Fragment>
            <header className="navbar">
                <div className="profile" onClick={() => document.getElementById('profileImageInput').click()}>
                    <div className="profile-text">{isAdmin ? `${userData.username}, ${userData.companyName}` : `${userData.firstname} ${userData.lastname}`}</div>
                </div>
                {/* Adding Logout Button with the same style as "Orders" button */}
                <button onClick={handleLogout} className="orders-button" >Log Out</button>
            </header>
            <main>
                {
                    isLoading ? <div>Loading...</div> : <div className="orders-container">
                        <div className="orders-title">{isAdmin ? "Orders" : "My Orders"}</div>
                        <div className="orders">
                            {adminOrders?.map((order, index) => {
                                return (
                                    <div key={index} className="order">
                                        <div className="order-details">
                                            <div className="order"><span
                                                className="order-title">Address: </span>{order.address}</div>
                                            <div className="order"><span
                                                className="order-title">Tariff:</span> {order.tariff}</div>
                                            <div className="order"><span
                                                className="order-title">Selected Date: </span>{new Date(order.selectedDate).toISOString().slice(0, 10)}
                                            </div>
                                            <div className="order"><span className="order-title">Created
                                            At: </span> {new Date(order.createdAt).toISOString().slice(0, 10)}</div>
                                            {
                                                isAdmin ? !order.admin ? <div className="accept-container">
                                                    <button onClick={() => acceptOrderHandler(order.id)}
                                                            className="accept-btn">Accept
                                                    </button>
                                                </div> : <span className="accepted">Accepted</span> : !order.admin ?
                                                    <span className="accepted">Pending</span> :
                                                    <span className="accepted">Accepted</span>
                                            }
                                        </div>
                                    </div>
                                )
                            })}
                        </div>

                    </div>
                }
                {
                    !isAdmin && <div className="buttons">
                        <button className="new-order-button" onClick={onClickNewOrder}>New Order</button>
                    </div>
                }
            </main>
        </Fragment>
    );
}

export default AdminOrders;
