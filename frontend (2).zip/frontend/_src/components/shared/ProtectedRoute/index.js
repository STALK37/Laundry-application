import { Outlet, Navigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { laundryApiHandler } from "../../../infrastructure/apiHandlers";

const ProtectedRoute = ({role}) => {
    const { data: userData, isLoading, status } = useQuery({
        queryKey: ["user"],
        queryFn: () => laundryApiHandler.getUser(),
    })

    console.log(userData, "userData");

    if(isLoading) {
        return <div>Loading...</div>;
    }

    if (status === 'error'){
        return <Navigate to="/"/>;
    }

    if(role !== userData.role) {
        return <Navigate to="/"/>;
    }

    return (
        <Outlet />
    );
};

export default ProtectedRoute;
