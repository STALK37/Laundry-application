import { createBrowserRouter, Outlet } from "react-router-dom";
import {
    AdminPartPage,
    AdminRegistrationPage,
    CustomerPartPage,
    CustomerRegistrationPage,
    RegistrationAsRolePage,
    MainLayout,
    SignInPage,
    OrdersPage
} from "../components/pages"
import ProtectedRoute from "../components/shared/ProtectedRoute";
import CustomerPart from "../components/pages/CustomerPart";

export const router = createBrowserRouter([
    {
        path: "/",
        element: <MainLayout/> ,
        children: [
            {
                path: "",
                element: <Outlet />,
                children: [
                    {
                        path: "",
                        element: <Outlet />,
                        children: [
                            {
                                path: "",
                                element: <RegistrationAsRolePage />,
                            },
                            {
                                path: "sign-in",
                                element: <SignInPage />,
                            }
                        ]
                    },

                ]
            },
            {
                path: "customer",
                element: <Outlet />,
                children: [
                    {
                        path: "",
                        element: <ProtectedRoute role="USER" />,
                        children: [
                            {
                                path: "",
                                element: <OrdersPage />,
                            },
                            {
                                path: "new-order",
                                element: <CustomerPart />,
                            }
                        ]
                    },
                    {
                        path: "registration",
                        element: <CustomerRegistrationPage />,
                    },
                ]
            },
            {
                path: "admin",
                element: <Outlet />,
                children: [
                    {
                        path: "",
                        element: <ProtectedRoute role="ADMIN" />,
                        children: [
                            {
                                path: "",
                                element: <AdminPartPage />,
                            },
                            {
                                path: "orders",
                                element: <OrdersPage />,
                            },
                        ]
                    },
                    {
                        path: "registration",
                        element: <AdminRegistrationPage />,
                    }
                ]
            }
        ]
    },
]);
