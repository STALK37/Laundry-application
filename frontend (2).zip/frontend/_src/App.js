// import Home from './pages/Home';
// import { RouterProvider } from 'react-router-dom';
// import Index from './pages/user';
// import AdminRegistration from './pages/adminRegistration';
// import AdminPart from './pages/adminPart';
//
// import { BrowserRouter as Router, Route } from 'react-router-dom';

import { ReactQueryConfigProvider } from "./providers";
import Routes from "./routes"
import './App.css';

function App() {
  return (
      <ReactQueryConfigProvider>
        <Routes/>
      </ReactQueryConfigProvider>
  );
}

export default App;
